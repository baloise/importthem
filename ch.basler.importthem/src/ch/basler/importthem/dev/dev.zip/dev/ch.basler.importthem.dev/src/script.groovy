
import org.eclipse.core.internal.resources.Folder;
import org.eclipse.core.resources.IFile;
import static ch.basler.importthem.handlers.Util.*

/**
 * @param map comes in empty - you fill it with working set name -> .project file mappings
 * @param selection the folders selected by the user
 */
def importThem(Map<String, Set<IFile>> map, Folder[] selection){
	seekProjects(map,selection)
}