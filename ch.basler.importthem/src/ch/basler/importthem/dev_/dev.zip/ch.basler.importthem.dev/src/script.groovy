import static ch.baler.importthem.handlers.Util.*
map = [:]
map['three']= [1,2,3] as Set
map['four five']= [4,5] as Set
map
